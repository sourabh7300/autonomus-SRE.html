terraform {
  required_version = ">= 1.6.0"

  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
  }

  # Store state remotely instead of locally — uncomment and configure
  # once you have an S3 bucket + DynamoDB lock table provisioned.
  # backend "s3" {
  #   bucket         = "cloudpilot-tfstate"
  #   key            = "cloudpilot/terraform.tfstate"
  #   region         = "ap-southeast-2"
  #   dynamodb_table = "cloudpilot-tf-locks"
  #   encrypt        = true
  # }
}

provider "aws" {
  region = var.aws_region
}

module "vpc" {
  source = "./modules/vpc"

  project_name       = var.project_name
  environment        = var.environment
  availability_zones = var.availability_zones
  admin_cidr         = var.admin_cidr
}

module "ec2" {
  source = "./modules/ec2"

  project_name       = var.project_name
  environment        = var.environment
  key_name           = var.key_name
  security_group_id  = module.vpc.app_security_group_id
  subnet_ids         = module.vpc.public_subnet_ids
  desired_capacity   = var.desired_capacity
}
