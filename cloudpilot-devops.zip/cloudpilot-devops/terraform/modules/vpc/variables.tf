variable "project_name" {
  type        = string
  description = "Name prefix used for tagging all resources"
}

variable "environment" {
  type        = string
  description = "Deployment environment, e.g. dev, staging, prod"
}

variable "vpc_cidr" {
  type        = string
  description = "CIDR block for the VPC"
  default     = "10.0.0.0/16"
}

variable "public_subnet_cidrs" {
  type        = list(string)
  description = "CIDR blocks for public subnets"
  default     = ["10.0.1.0/24", "10.0.2.0/24"]
}

variable "availability_zones" {
  type        = list(string)
  description = "Availability zones for the subnets"
}

variable "admin_cidr" {
  type        = string
  description = "CIDR block allowed to SSH into instances"
}
