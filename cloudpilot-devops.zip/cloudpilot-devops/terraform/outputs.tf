output "vpc_id" {
  value = module.vpc.vpc_id
}

output "autoscaling_group_name" {
  value = module.ec2.autoscaling_group_name
}
