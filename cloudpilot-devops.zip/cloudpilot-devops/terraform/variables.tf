variable "aws_region" {
  type    = string
  default = "ap-southeast-2" # Sydney — closest AWS region to Australia
}

variable "project_name" {
  type    = string
  default = "cloudpilot"
}

variable "environment" {
  type    = string
  default = "dev"
}

variable "availability_zones" {
  type    = list(string)
  default = ["ap-southeast-2a", "ap-southeast-2b"]
}

variable "admin_cidr" {
  type        = string
  description = "Your IP in CIDR form, e.g. 203.0.113.4/32 — restrict SSH access"
}

variable "key_name" {
  type        = string
  description = "Existing AWS EC2 key pair name"
}

variable "desired_capacity" {
  type    = number
  default = 2
}
