#!/usr/bin/env bash
# End-to-end local orchestration: provision infra, then configure it.
# In production this is done automatically by the GitHub Actions workflow —
# this script is for manual runs and demos.
set -euo pipefail

cd "$(dirname "$0")/../terraform"

echo "==> Terraform init"
terraform init

echo "==> Terraform plan"
terraform plan -out=tfplan

read -p "Apply this plan? [y/N] " confirm
if [[ "$confirm" != "y" ]]; then
  echo "Aborted."
  exit 0
fi

echo "==> Terraform apply"
terraform apply tfplan

echo "==> Generating Ansible inventory from Terraform output"
# In a real setup, replace this with a dynamic inventory script
# that queries the ASG's running instances via the AWS API.
terraform output -json > ../ansible/terraform_output.json

echo "==> Running Ansible playbook"
cd ../ansible
ansible-playbook -i inventory.ini playbook.yml

echo "==> Done. App should be live on the instance's public IP (port 80)."
