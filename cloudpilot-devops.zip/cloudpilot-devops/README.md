# CloudPilot 🚀

A self-contained DevOps / cloud automation project demonstrating the full
lifecycle: **Infrastructure as Code → Containerization → CI/CD → Configuration
Management → Monitoring.**

Built as a portfolio project to demonstrate practical, production-style
DevOps workflows rather than isolated tool usage.

## What it does

Pushing to `main` automatically:
1. Runs the test suite against the demo Flask app
2. Validates all Terraform code (`fmt`, `validate`)
3. Builds a Docker image and pushes it to GitHub Container Registry
4. Uses Ansible to roll the new image out to a fleet of EC2 instances
   provisioned by Terraform, with a health check gate

The infrastructure is a VPC with public subnets across two Availability
Zones, an Auto Scaling Group running the containerized app, and a
Prometheus + Grafana stack for observability.

See [`docs/architecture.md`](docs/architecture.md) for a diagram and design
rationale.

## Stack

| Layer                  | Tool                          |
|-------------------------|-------------------------------|
| Infrastructure as Code | Terraform (AWS: VPC, ASG, EC2) |
| Containerization       | Docker                        |
| CI/CD                  | GitHub Actions                |
| Configuration Mgmt     | Ansible                       |
| Monitoring             | Prometheus + Grafana          |
| App                    | Python / Flask                |

## Repo structure

```
cloudpilot-devops/
├── app/                  # Flask demo app + Dockerfile + tests
├── terraform/            # IaC: VPC + EC2/ASG modules
├── ansible/               # Configuration management + deployment playbook
├── monitoring/            # Prometheus + Grafana via docker-compose
├── .github/workflows/     # CI/CD pipeline
├── scripts/               # Manual end-to-end deploy helper
└── docs/                  # Architecture notes
```

## Running it locally (no AWS needed)

```bash
cd monitoring
docker compose up --build
```

- App: http://localhost:5000
- Prometheus: http://localhost:9090
- Grafana: http://localhost:3000 (admin / admin)

## Deploying to AWS

Requires an AWS account, an existing EC2 key pair, and the AWS CLI configured.

```bash
cd terraform
cp terraform.tfvars.example terraform.tfvars   # fill in your values
terraform init
terraform plan
terraform apply
```

Then generate `ansible/inventory.ini` from the instances' public IPs
(see `ansible/inventory.ini.example`) and run:

```bash
cd ansible
ansible-playbook -i inventory.ini playbook.yml
```

Or just run the whole thing with:

```bash
./scripts/deploy.sh
```

In production this whole flow is automated by
[`.github/workflows/ci-cd.yml`](.github/workflows/ci-cd.yml) — see that
file for the required GitHub Secrets (`EC2_SSH_KEY`, registry auth is
handled automatically via `GITHUB_TOKEN`).

## Why this project

This was built to demonstrate:
- Writing modular, reviewable Terraform rather than one giant file
- Separating infrastructure provisioning from configuration management
- A CI/CD pipeline with real gates (tests + validation before deploy,
  health checks before considering a deploy successful)
- Basic observability, not just "it deployed" but "it's actually healthy"

## License

MIT — feel free to fork and adapt for your own portfolio.
