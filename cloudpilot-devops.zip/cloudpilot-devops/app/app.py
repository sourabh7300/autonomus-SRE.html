"""
CloudPilot demo microservice.
A minimal Flask app used to demonstrate the full CI/CD + IaC pipeline.
Exposes a health endpoint (used by load balancer / monitoring) and
a metrics endpoint (scraped by Prometheus).
"""
from flask import Flask, jsonify
from prometheus_client import Counter, generate_latest, CONTENT_TYPE_LATEST
import socket
import time

app = Flask(__name__)

REQUEST_COUNT = Counter(
    "cloudpilot_requests_total", "Total requests received", ["endpoint"]
)

START_TIME = time.time()


@app.route("/")
def index():
    REQUEST_COUNT.labels(endpoint="/").inc()
    return jsonify(
        {
            "service": "cloudpilot-demo",
            "message": "Hello from CloudPilot 🚀",
            "hostname": socket.gethostname(),
            "uptime_seconds": round(time.time() - START_TIME, 2),
        }
    )


@app.route("/health")
def health():
    # Used by the ALB / Ansible-configured healthcheck and container orchestrator
    return jsonify({"status": "healthy"}), 200


@app.route("/metrics")
def metrics():
    REQUEST_COUNT.labels(endpoint="/metrics").inc()
    return generate_latest(), 200, {"Content-Type": CONTENT_TYPE_LATEST}


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
