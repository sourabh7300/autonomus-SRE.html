# CloudPilot Architecture

```
Developer
   |
   | git push
   v
GitHub -------------------------------------------------------
   |
   |  GitHub Actions (.github/workflows/ci-cd.yml)
   |    1. Test (pytest)
   |    2. Validate infra (terraform fmt/validate)
   |    3. Build + push Docker image -> GHCR
   |    4. Deploy: Ansible connects to EC2 fleet, pulls new image,
   |       does a rolling container restart
   v
AWS (provisioned by Terraform)
   VPC
    |- Public Subnets (2x, across AZs)
    |    |- Auto Scaling Group (EC2, min 1 / desired 2 / max 3)
    |         |- Docker container: Flask app (port 5000 -> 80)
    |- Security Group (80 open, 22 restricted to admin_cidr)

Monitoring
   Prometheus scrapes /metrics on each instance
   Grafana visualizes request counts, uptime, health
```

## Why this design

- **Terraform** owns infrastructure state so environments are reproducible
  and reviewable via pull request (`terraform plan` output).
- **Modules** (`vpc`, `ec2`) keep the root config small and make the
  networking layer reusable across environments (dev/staging/prod) by
  just changing variables.
- **Ansible** handles configuration drift and app deployment separately
  from infrastructure provisioning — a standard separation of concerns
  in DevOps (immutable infra + configuration management).
- **GitHub Actions** ties it together: every push is tested, validated,
  built, and deployed automatically — no manual steps in the happy path.
- **Prometheus/Grafana** give observability so a broken deploy is caught
  by metrics, not by a user complaint.

## What I'd add next

- Blue/green or canary deploys instead of in-place rolling restart
- Terraform remote state (S3 + DynamoDB locking) — stubbed in `main.tf`
- Dynamic Ansible inventory sourced directly from AWS ASG instead of a
  static file
- Alertmanager rules wired to Slack/email for on-call style alerting
