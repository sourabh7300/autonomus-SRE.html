import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import 'dotenv/config';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// ── /api/chat — proxies Claude API server-side (no CORS, no key exposure) ──
app.post('/api/chat', async (req, res) => {
  const { messages } = req.body;

  if (!messages || !Array.isArray(messages)) {
    return res.status(400).json({ error: 'messages array required' });
  }

  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    return res.status(500).json({ error: 'ANTHROPIC_API_KEY not set in .env' });
  }

  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-6',
        max_tokens: 1024,
        system: `You are J.A.R.V.I.S (Just A Rather Very Intelligent System), the AI of Tony Stark. You are precise, calm, highly capable, and dryly witty. You answer any question — science, technology, coding, general knowledge, philosophy, current events, anything the user asks. Keep answers concise and natural for speech: 2–4 sentences unless the user requests more detail or code. When you include code, use markdown code fences. Never break character.`,
        messages
      })
    });

    if (!response.ok) {
      const errBody = await response.text();
      console.error('Anthropic API error:', response.status, errBody);
      return res.status(response.status).json({ error: `API error ${response.status}: ${errBody}` });
    }

    const data = await response.json();
    res.json(data);

  } catch (err) {
    console.error('Server error:', err.message);
    res.status(500).json({ error: 'Server error: ' + err.message });
  }
});

// ── /api/tts — optional: proxy ElevenLabs so key stays server-side ──
app.post('/api/tts', async (req, res) => {
  const { text, voice_id } = req.body;
  const elKey = process.env.ELEVENLABS_API_KEY;

  if (!elKey || !voice_id) {
    return res.status(400).json({ error: 'ElevenLabs key or voice_id missing' });
  }

  try {
    const r = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${voice_id}`, {
      method: 'POST',
      headers: { 'xi-api-key': elKey, 'Content-Type': 'application/json', 'Accept': 'audio/mpeg' },
      body: JSON.stringify({
        text,
        model_id: 'eleven_multilingual_v2',
        voice_settings: { stability: 0.5, similarity_boost: 0.8 }
      })
    });

    if (!r.ok) throw new Error('ElevenLabs status ' + r.status);
    const buf = await r.arrayBuffer();
    res.set('Content-Type', 'audio/mpeg');
    res.send(Buffer.from(buf));
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// fallback — serve index.html for any unknown route
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`\n✦ J.A.R.V.I.S ONLINE`);
  console.log(`✦ Open: http://localhost:${PORT}\n`);
});
