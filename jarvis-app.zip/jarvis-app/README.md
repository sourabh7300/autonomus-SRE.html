# J.A.R.V.I.S — AI Voice Assistant

## Quick Start (3 steps)

### 1. Install dependencies
```bash
npm install
```

### 2. Add your API key
Copy `.env.example` to `.env` and fill in your key:
```bash
cp .env.example .env
```
Then open `.env` and paste your Anthropic API key:
```
ANTHROPIC_API_KEY=sk-ant-xxxxxxxxxx
```
Get your key at: https://console.anthropic.com

### 3. Start JARVIS
```bash
npm start
```
Open **http://localhost:3000** in Chrome.

---

## Voice Input
- **Tap the arc reactor** or **press Space** to speak
- **Click the 🎤 mic button** to start/stop listening
- Or **type** in the text box and press Enter / SEND

## Voice Output (optional — your cloned voice)
Add to your `.env`:
```
ELEVENLABS_API_KEY=your-key
ELEVENLABS_VOICE_ID=your-voice-id
```
Get these from https://elevenlabs.io

---

## Deploy Online (free link anyone can visit)

### Option A — Render.com
1. Push this folder to a GitHub repo
2. Go to render.com → New Web Service → connect repo
3. Set environment variable `ANTHROPIC_API_KEY` in Render dashboard
4. Deploy → you get a live https link

### Option B — Railway
1. Go to railway.app → New Project → Deploy from GitHub
2. Add `ANTHROPIC_API_KEY` in environment variables
3. Deploy — live in 2 minutes

---

## Why no "failed to fetch" error?
The app calls **your own server** at `/api/chat` instead of calling Anthropic directly from the browser. The server then calls Anthropic with your API key. This is the correct and secure architecture — no CORS issues, no key exposed to users.
